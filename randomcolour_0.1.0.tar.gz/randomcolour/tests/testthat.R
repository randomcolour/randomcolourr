library(testthat)
library(randomcolour)

test_check("randomcolour")
